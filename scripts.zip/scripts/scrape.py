import requests
from bs4 import BeautifulSoup
import logging
import re
from typing import Any, Dict, List

def scrape_books(**kwargs: Any) -> List[Dict[str, Any]]:
    """
    Scrapes book data from books.toscrape.com and pushes the result to XCom.
    Designed for use with Airflow's PythonOperator.
    """
    products: List[Dict[str, Any]] = []
    url = "http://books.toscrape.com/catalogue/page-1.html"
    page_num = 1

    logging.info("🚀 Starting scrape_books task...")

    try:
        while url:
            logging.info(f"📄 Scraping page {page_num}: {url}")
            res = requests.get(url, timeout=10)
            res.raise_for_status()

            soup = BeautifulSoup(res.text, "html.parser")
            for article in soup.select("article.product_pod"):
                try:
                    # Title
                    title = article.h3.a.get("title", "Untitled")

                    # Price (clean unwanted characters)
                    price_tag = article.select_one(".price_color")
                    raw_price = price_tag.text if price_tag else "0.00"
                    clean_price = re.sub(r"[^0-9.]", "", raw_price)
                    price = float(clean_price) if clean_price else 0.0

                    # Availability
                    availability_tag = article.select_one(".availability")
                    availability = availability_tag.text.strip() if availability_tag else "Unavailable"

                    # Category (from breadcrumb)
                    category_tag = soup.select_one("ul.breadcrumb li:nth-of-type(3)")
                    category = category_tag.text.strip() if category_tag else "Unknown"

                    products.append({
                        "title": title,
                        "price_gbp": price,
                        "availability": availability,
                        "category": category
                    })
                except Exception as e:
                    logging.warning(f"⚠️ Error parsing product: {e}")
                    continue

            # Next page
            next_page = soup.select_one("li.next a")
            url = (
                f"http://books.toscrape.com/catalogue/{next_page['href']}"
                if next_page else None
            )
            page_num += 1

        logging.info(f"✅ Scraped {len(products)} products in total.")

        # Push to XCom if running under Airflow
        if "ti" in kwargs:
            kwargs["ti"].xcom_push(key="scraped_books", value=products)
            logging.info("📦 Pushed scraped_books to XCom")
        else:
            logging.info("⚠️ No Airflow context (ti) found — standalone mode")
            print(products[:5])  # preview first 5 items

        return products

    except Exception as e:
        logging.error(f"🔥 scrape_books failed: {e}")
        raise
