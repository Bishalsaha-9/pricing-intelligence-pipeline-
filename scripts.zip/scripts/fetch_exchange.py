import requests
import psycopg2
from datetime import datetime
from airflow.utils.log.logging_mixin import LoggingMixin

logger = LoggingMixin().log

def fetch_and_store_exchange_rate(conn_params):
    try:
        logger.info("🌐 Starting exchange rate fetch...")

        # Fetch USD to INR exchange rate
        response = requests.get("https://api.exchangerate.host/latest?base=USD&symbols=INR", timeout=10)
        response.raise_for_status()
        data = response.json()

        rate = data["rates"]["INR"]
        date = datetime.utcnow().date()

        logger.info(f"✅ Fetched rate: {rate} for date: {date}")

        # Connect to Postgres
        conn = psycopg2.connect(conn_params)
        with conn.cursor() as cur:
            cur.execute("""
                INSERT INTO staging_exchange_rates (date, rate)
                VALUES (%s, %s)
                ON CONFLICT (date) DO UPDATE SET rate = EXCLUDED.rate;
            """, (date, rate))
            conn.commit()
        conn.close()

        logger.info("✅ Exchange rate stored successfully in database.")

    except requests.RequestException as e:
        logger.error(f"🌐 Network error: {str(e)}")
        raise
    except psycopg2.Error as e:
        logger.error(f"🛠 Database error: {str(e)}", exc_info=True)
        raise
    except Exception as e:
        logger.error(f"❌ Unexpected error: {str(e)}", exc_info=True)
        raise
