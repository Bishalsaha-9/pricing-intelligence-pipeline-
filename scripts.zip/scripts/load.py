import psycopg2
import logging

logging.basicConfig(level=logging.INFO)

def load_to_db(transformed_data, conn_params):
    conn = psycopg2.connect(**conn_params)
    cur = conn.cursor()
    for item in transformed_data:
        cur.execute("""
            INSERT INTO products (product_id, title, price_gbp, price_inr, category, availability, price_tier)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
            ON CONFLICT (product_id) DO UPDATE SET
                title = EXCLUDED.title,
                price_gbp = EXCLUDED.price_gbp,
                price_inr = EXCLUDED.price_inr,
                category = EXCLUDED.category,
                availability = EXCLUDED.availability,
                price_tier = EXCLUDED.price_tier
        """, (item['product_id'], item['title'], item['price_gbp'], item['price_inr'], item['category'], item['availability'], item['price_tier']))
    conn.commit()
    cur.close()
    conn.close()
    logging.info(f"Loaded {len(transformed_data)} records")

if __name__ == "__main__":
    # Test with dummy
    data = [{'product_id': 'test', 'title': 'Test', 'price_gbp': 10, 'price_inr': 1000, 'category': 'Test', 'availability': '5', 'price_tier': 'moderate'}]
    load_to_db(data, {'dbname': 'airflow', 'user': 'airflow', 'password': 'airflow', 'host': 'localhost'})