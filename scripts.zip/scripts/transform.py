import pandas as pd
import hashlib
import psycopg2
import logging

logging.basicConfig(level=logging.INFO)

def get_latest_rate(conn_params):
    conn = psycopg2.connect(**conn_params)
    cur = conn.cursor()
    cur.execute("SELECT rate FROM staging_exchange_rates ORDER BY date DESC LIMIT 1")
    rate = cur.fetchone()[0]
    cur.close()
    conn.close()
    return rate

def transform_data(raw_data, rate):
    df = pd.DataFrame(raw_data)
    # Clean text
    df['title'] = df['title'].str.strip().str.lower()
    df['category'] = df['category'].str.strip().str.capitalize()
    df['availability'] = df['availability'].str.strip().str.replace('In stock (', '').str.replace(' available)', '')
    # Convert to INR
    df['price_inr'] = df['price_gbp'] * rate
    # Derive price tier
    df['price_tier'] = pd.cut(df['price_inr'], bins=[0, 500, 1500, float('inf')], labels=['cheap', 'moderate', 'expensive'])
    # Generate hashed ID
    df['product_id'] = df.apply(lambda row: hashlib.sha256(f"{row['title']}_{row['category']}_{row['price_gbp']}".encode()).hexdigest(), axis=1)
    logging.info("Transformation complete")
    return df.to_dict('records')

if __name__ == "__main__":
    # Test
    raw = [{'title': 'Test Book', 'price_gbp': 10.0, 'category': 'Test', 'availability': 'In stock (5 available)'}]
    rate = 100.0
    print(transform_data(raw, rate))