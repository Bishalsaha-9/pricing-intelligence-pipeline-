import sys
sys.path.insert(0, '/opt/airflow/scripts')  # Add scripts folder to Python path

from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime

from scrape import scrape_books   # <-- Import your scrape_books function

default_args = {
    'owner': 'airflow',
    'start_date': datetime(2025, 8, 23),
    'retries': 1,
}

dag = DAG(
    'scrape_dag',
    default_args=default_args,
    description='DAG just to test calling scrape_books',
    schedule_interval=None,
    catchup=False,
)

scrape_task = PythonOperator(
    task_id='scrape_books_task',
    python_callable=scrape_books,
    dag=dag,
)

# No dependencies, single task!