from airflow import DAG
from airflow.operators.dummy import DummyOperator
from datetime import datetime

dag = DAG(
    'test_dag',
    description='A simple test DAG',
    schedule_interval=None,  # Manual trigger only
    start_date=datetime(2025, 8, 23),
    catchup=False,
)

start = DummyOperator(task_id='start', dag=dag)
end = DummyOperator(task_id='end', dag=dag)

start >> end