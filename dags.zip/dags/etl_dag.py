import sys
import os
import logging
from datetime import datetime, timedelta

from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.providers.postgres.hooks.postgres import PostgresHook

# ---- Path Setup ----
dag_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.abspath(os.path.join(dag_dir, ".."))
scripts_path = os.path.join(project_root, "scripts")

if scripts_path not in sys.path:
    sys.path.insert(0, scripts_path)

# ---- Import Custom Scripts ----
from scrape import scrape_books
from fetch_exchange import fetch_and_store_exchange_rate
from transform import transform_data, get_latest_rate
from load import load_to_db

# ---- Default Arguments ----
default_args = {
    'owner': 'bishal',
    'depends_on_past': False,
    'start_date': datetime(2025, 8, 1),
    'retries': 3,
    'retry_delay': timedelta(minutes=5),
}

# ---- DAG Definition ----
with DAG(
    dag_id='pricing_etl_daily',
    default_args=default_args,
    description='Daily ETL for pricing intelligence',
    schedule_interval='@daily',
    catchup=False,
    tags=['etl', 'pricing'],
) as dag:

    # ---- Helper: Get Postgres Connection URI ----
    def get_conn_params():
        hook = PostgresHook(postgres_conn_id='postgres_default')
        return hook.get_uri()

    # ---- Task 1: Scrape Books ----
    scrape_task = PythonOperator(
        task_id='scrape_books',
        python_callable=scrape_books,
        retries=3,
        retry_delay=timedelta(minutes=5),
    )

    # ---- Task 2: Fetch Exchange Rate ----
    fetch_task = PythonOperator(
        task_id='fetch_exchange',
        python_callable=fetch_and_store_exchange_rate,
        op_kwargs={'conn_params': get_conn_params()},
        retries=3,
        retry_delay=timedelta(minutes=5),
    )

    # ---- Task 3: Transform Data ----
    def transform_wrapper(**context):
        logging.info("🔄 Transforming scraped data...")
        raw_data = context['ti'].xcom_pull(task_ids='scrape_books', key='scraped_books')
        if not raw_data:
            raise ValueError("❌ No scraped data found in XCom.")
        rate = get_latest_rate(get_conn_params())
        return transform_data(raw_data, rate)

    transform_task = PythonOperator(
        task_id='transform_data',
        python_callable=transform_wrapper,
        retries=3,
        retry_delay=timedelta(minutes=5),
    )

    # ---- Task 4: Load to Database ----
    def load_wrapper(**context):
        logging.info("📥 Loading transformed data into database...")
        transformed = context['ti'].xcom_pull(task_ids='transform_data')
        if not transformed:
            raise ValueError("❌ No transformed data found in XCom.")
        load_to_db(transformed, get_conn_params())

    load_task = PythonOperator(
        task_id='load_to_db',
        python_callable=load_wrapper,
        retries=3,
        retry_delay=timedelta(minutes=5),
    )

    # ---- Task Dependencies ----
    scrape_task >> fetch_task >> transform_task >> load_task
